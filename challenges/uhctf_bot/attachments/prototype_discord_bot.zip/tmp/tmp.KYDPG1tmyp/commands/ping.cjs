const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
    data: new SlashCommandBuilder().setName('ping').setDescription(
        'Replies with Pong!'),

    async execute(command) {
        if (command.user.debug_mode) {
            return command.reply('Pong took ' + (Date.now() - command.createdTimestamp) + 'ms');
        }

        return command.reply('Pong! 🏓');
    },
};