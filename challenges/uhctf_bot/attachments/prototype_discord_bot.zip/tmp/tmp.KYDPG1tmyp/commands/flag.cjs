const { SlashCommandBuilder } = require('@discordjs/builders');
const { Formatters } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder().setName('flag').setDescription(
        "What is this doing here?"),

    async execute(command) {
        if (command.user.debug_mode) {
            return command.reply(Formatters.inlineCode(process.env.FLAG));
        }

        return command.reply("Do you need this one? 🏳️");
    },
};